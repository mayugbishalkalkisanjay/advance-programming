package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse;


import databases.fukuDao;

@SuppressWarnings("serial")
@WebServlet("/registration")

public class fukuUserRegistration  extends HttpServlet {
		public void service(HttpServletRequest request,HttpServletResponse response) throws  IOException, ServletException {
			
			
			String id = request.getParameter("UId");
			String name = request.getParameter("UName");
			String gender = request.getParameter("gender");
			String password = request.getParameter("password");
			
			System.out.println(id+name+gender+password);

			

			
			fukuDao fdao = new fukuDao();
			String message = fdao.fukuUserRegister(id, name, gender, password);
		
		}
}



package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import databases.fukuDao;

@WebServlet("/login")
public class login extends HttpServlet {
	public void service(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		
		fukuDao fDao = new fukuDao();
		boolean isValid =  fDao.checkLogin(id,password);
		if(isValid == true) {
			HttpSession session = request.getSession();
			session.setAttribute("loggedInId",id);
			response.sendRedirect("index.html");
		}
		else {
			response.sendRedirect("Login.jsp");		
		}
		
	}
}
